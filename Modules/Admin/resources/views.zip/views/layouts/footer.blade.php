 <script>
    // Hide loader when the page is fully loaded
    window.addEventListener("load", () => {
      const loader = document.getElementById("loader");
      loader.classList.add("hidden");
    });
  </script>
<footer class="main-footer"> <strong>Copyright &copy; 2024-2025.</strong> All rights reserved. <div class="float-right d-none d-sm-inline-block"> <b>Version</b> 3.2.0 </div>
</footer>

